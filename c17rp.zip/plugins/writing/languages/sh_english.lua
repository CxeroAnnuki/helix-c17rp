
LANGUAGE = {
	paper = "Paper"
}
